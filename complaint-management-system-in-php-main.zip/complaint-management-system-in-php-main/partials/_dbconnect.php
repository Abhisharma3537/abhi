<?php

$server = "localhost";
$username = "root";
$password = "";
$database = "project";

$connectionquery = mysqli_connect($server, $username, $password, $database);
?>